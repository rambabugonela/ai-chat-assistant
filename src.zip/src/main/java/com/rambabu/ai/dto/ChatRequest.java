package com.rambabu.ai.dto;

import com.rambabu.ai.prompt.PromptType;
import jakarta.validation.constraints.NotBlank;

public record ChatRequest(
        @NotBlank(message = "Message")
        String message,
        PromptType promptType
) {
}
