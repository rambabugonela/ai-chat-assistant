package com.rambabu.ai.routing;

import com.rambabu.ai.dto.ChatResponse;
import com.rambabu.ai.routing.handler.QueryRouteHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class RoutingService {

    private final IntentClassifier intentClassifier;

    private final Map<QueryRoute, QueryRouteHandler> handlerMap;
    private static final Logger log =
            LoggerFactory.getLogger(RoutingService.class);
    public RoutingService(IntentClassifier intentClassifier,
                          List<QueryRouteHandler> handlers) {

        this.intentClassifier = intentClassifier;


        this.handlerMap = handlers.stream()
                .collect(Collectors.toMap(
                        QueryRouteHandler::supportedRoute,
                        Function.identity()));
    }

    public ChatResponse route(String message, String sessionId) {

        RoutingDecision decision =
                intentClassifier.classify(message);

        log.info("Selected Route : {}", decision.route());

        return handlerMap.get(decision.route()).handle(message, sessionId);
    }
}
